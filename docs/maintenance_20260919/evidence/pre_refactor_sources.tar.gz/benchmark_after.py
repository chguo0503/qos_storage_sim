#!/usr/bin/env python3
"""Small deterministic data-plane regression; rerun against a supplied source root."""
import argparse
import cProfile
from datetime import datetime, timezone
import hashlib
import importlib
import io
import json
from pathlib import Path
import pstats
import sys
import time
from unittest.mock import patch


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--runner-module',default='inputs.runners.run_coflow_experiments')
    p.add_argument('--profile-policy',default='once')
    p.add_argument('--compare-to',type=Path)
    args=p.parse_args()
    root=args.source_root.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    sys.path.insert(0,str(root))
    from simulator.core import continuous_batch_sim as native
    from simulator.core import sim
    from inputs.runners.run_baseline_npu32_stress import load_manifest,save_manifest,write_json
    from inputs.runners.run_shared_path_experiments import logical_input_fingerprint,summarize_window
    runner=importlib.import_module(args.runner_module)
    source_files=sorted((root/'simulator').rglob('*.py'))+sorted((root/'inputs').rglob('*.py'))+[root/'data']
    hashes={str(path.relative_to(root)):hashlib.sha256(path.read_bytes()).hexdigest() for path in source_files}
    io_gib=176*1024/2**30
    profiles=(('SS',24,120.0),('LL',96,1500.0),('LS',48,550.0),('SL',16,300.0))
    requests=[]
    for npu in range(32):
        for position in range(4):
            category,blocks,C_us=profiles[(npu+position)%4]
            rid=npu*100+position
            load=dict(request_id=rid,npu_id=npu,original_request_id=rid,generation=position,
                role=category,category=category,seq_len_k=32,nql=256,
                per_layer_us=C_us,per_layer_kv_gb=blocks*io_gib,
                required_bw_input_gbps=blocks*io_gib*1e6/C_us,constructed_profile=True)
            placement=(tuple((sim.block_ring_hash_disk_id(rid,k,3),io_gib) for k in range(blocks)),)
            requests.append(native.ContinuousBatchRequest.from_normalized(rid,npu,0.,load,placement))
    requests=tuple(requests)
    metadata=dict(num_npu=32,num_ssu=3,n_layers=8,seed=17,equal_176kib_blocks=True,
        layout=sim.PLACEMENT_BLOCK_RING_HASH,order='deterministic_rotated_four_profiles',
        input_fingerprint=native.continuous_batch_input_fingerprint(requests),
        logical_input_fingerprint=logical_input_fingerprint(requests),constructed_profile=True)
    save_manifest(out/'manifest.json.gz',requests,metadata)
    restored,restored_meta=load_manifest(out/'manifest.json.gz')
    assert restored==requests and restored_meta==metadata
    results=[]
    for policy in ('asu_baseline','od_baseline','once'):
        # Observe complete I/O only; do not influence scheduling or callbacks.
        observed=[];original=native._register_complete
        def observe(context,flow):
            observed.append([flow.request_id,flow.npu_id,flow.disk_id,flow.queue_id,flow.layer,
                             flow.block_idx,flow.ssd_activation_time,flow.link_enqueue_time,
                             flow.link_end_time])
            return original(context,flow)
        profiler=cProfile.Profile() if policy==args.profile_policy else None
        started=time.perf_counter()
        with patch.object(native,'_register_complete',observe):
            if profiler:profiler.enable()
            result=runner.run_case(requests,metadata,strategy=policy,assignment='fixed')
            if profiler:profiler.disable()
        wall=time.perf_counter()-started
        result.pop('_source_texts',None)
        summary=result['summary']
        assert all(summary['invariants'].values())
        assert summary['request_count']==128
        assert summary['completed_blocks']==sum(len(q.placement[0])*8 for q in requests)==47104
        assert len(observed)==summary['completed_blocks']
        request_rows=sorted(summary['request_metrics'],key=lambda r:r['request_id'])
        layer_rows=sorted(summary['microbatch_metrics'],key=lambda r:r['member_request_ids'])
        completion_rows=sorted([[r['request_id'],r['admission_time_ms'],r['completion_time_ms'],r['own_compute_ms']] for r in request_rows])
        signature=dict(request_metrics_sha256=digest(request_rows),layer_metrics_sha256=digest(layer_rows),
            io_completion_order_and_timing_sha256=digest(observed),completion_times_sha256=digest(completion_rows))
        windows=[summarize_window(summary,a,z) for a,z in ((2.,12.),(8.,20.))]
        record=dict(policy=policy,wall_seconds=wall,makespan_ms=summary['makespan_ms'],
            fleet_U_percent=100*summary['fleet_npu_compute_utilization'],
            request_count=summary['request_count'],completed_blocks=summary['completed_blocks'],
            completed_read_gib=summary['completed_read_gb'],cross_request_L0_prefetches=summary['cross_request_layer0_prefetches'],
            input_fingerprint=result['input_fingerprint'],signature=signature,
            windows=[dict(start_ms=w['start_ms'],end_ms=w['end_ms'],U_percent=100*w['mean_npu_utilization'],
                          per_npu_U_percent=[100*v for v in w['npu_utilizations']]) for w in windows],
            source_unchanged=all(hashlib.sha256((root/n).read_bytes()).hexdigest()==value for n,value in hashes.items()))
        assert record['source_unchanged']
        write_json(out/f'{policy}.result.json.gz',result)
        write_json(out/f'{policy}.completion_signature.json',dict(signature=signature,request_completion_times=completion_rows))
        if profiler:
            profiler.dump_stats(out/f'{policy}.prof')
            text=io.StringIO();stats=pstats.Stats(profiler,stream=text).strip_dirs().sort_stats('cumulative');stats.print_stats(35)
            stats.sort_stats('tottime').print_stats(25);(out/f'{policy}.profile.txt').write_text(text.getvalue())
        results.append(record)
        print(json.dumps({k:record[k] for k in ('policy','wall_seconds','makespan_ms','fleet_U_percent','completed_blocks')}),flush=True)
    record=dict(created_utc=datetime.now(timezone.utc).isoformat(),argv=sys.argv,source_root=str(root),
        python=sys.executable,python_version=sys.version,source_sha256=hashes,
        requests_per_npu=4,num_npu=32,num_ssu=3,n_layers=8,profiles=profiles,
        input_fingerprint=metadata['input_fingerprint'],results=results,
        note='Synthetic quick regression. Window units are milliseconds; not the scientific warm-window study. cProfile affects wall time only.')
    if args.compare_to:
        old=json.loads(args.compare_to.read_text());checks=[]
        for a,b in zip(old['results'],results):
            checks.append(dict(policy=b['policy'],same_signature=a['signature']==b['signature'],
                makespan_error_ms=abs(a['makespan_ms']-b['makespan_ms']),
                U_error_pp=abs(a['fleet_U_percent']-b['fleet_U_percent'])))
        record['comparison']=checks
        assert all(c['same_signature'] and c['makespan_error_ms']==0 and c['U_error_pp']==0 for c in checks),checks
    (out/'benchmark.json').write_text(json.dumps(record,indent=2)+'\n')


if __name__=='__main__':
    main()
