"""simulator adapters package."""
