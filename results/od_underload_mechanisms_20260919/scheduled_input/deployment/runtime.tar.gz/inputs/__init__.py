"""inputs package."""
