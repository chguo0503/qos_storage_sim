"""Static ASU/OD baselines: shared Path0 or one exclusive Path per NPU.

``baseline`` is retained only as an ASU compatibility alias for frozen runners.
OD divides each disk's CIR equally and retains the native work-conserving
surplus scheduler (PIR is infinite). No policy here changes request ordering,
placement, or runtime CIR registers.
"""

import math


BASELINE_STRATEGIES = ("asu_baseline", "od_baseline")


def canonical_baseline_name(strategy):
    return "asu_baseline" if strategy == "baseline" else strategy


def baseline_path_ids(io_count, path_id=0):
    return (path_id,) * io_count


def od_npu_path_ids(num_npu):
    """Spread the exclusive paths evenly across the eight hardware groups."""
    if not isinstance(num_npu, int) or isinstance(num_npu, bool) or not 1 <= num_npu <= 256:
        raise ValueError("OD baseline requires 1 <= num_npu <= 256")
    return tuple((npu % 8) * 32 + npu // 8 for npu in range(num_npu))


def baseline_qos_config(strategy, num_npu, disk_bw_gib_s=40.0):
    """Return the original ASU table or OD's equal static per-NPU CIR table.

    Unbound OD paths have zero CIR and zero surplus weight and are never
    eligible for routing. The existing simulator requires infinite PIR on
    every hardware register, including unused paths.
    """
    from continuous_prefill_client import static_qos_config
    from sim import StaticQoSConfig

    strategy = canonical_baseline_name(strategy)
    if strategy != "od_baseline":
        return static_qos_config()
    if not math.isfinite(disk_bw_gib_s) or disk_bw_gib_s <= 0:
        raise ValueError("disk bandwidth must be finite and positive")
    paths = set(od_npu_path_ids(num_npu))
    return StaticQoSConfig(
        path_cirs=tuple(disk_bw_gib_s / num_npu if p in paths else 0.0 for p in range(256)),
        path_pirs=(float("inf"),) * 256,
        path_weights=tuple(1.0 if p in paths else 0.0 for p in range(256)),
        group_weights=(1.0,) * 8,
        category_paths_per_group=(12, 4, 12, 4),
    )


def baseline_configuration(strategy, num_npu, disk_bw_gib_s=40.0):
    """JSON-safe explicit policy semantics for audit/reporting."""
    strategy = canonical_baseline_name(strategy)
    if strategy not in BASELINE_STRATEGIES:
        return None
    od = strategy == "od_baseline"
    return {
        "canonical_strategy": strategy,
        "usable_path_count_per_ssu": num_npu if od else 1,
        "npu_path_ids": list(od_npu_path_ids(num_npu)) if od else [0] * num_npu,
        "exclusive_per_npu": od,
        "per_npu_cir_gib_s": disk_bw_gib_s / num_npu if od else None,
        "path_pir": "unlimited",
        "idle_capacity_borrowing": True,
        "surplus_policy": "native equal-weight active-group WRR, then active-path WRR",
        "unused_od_path_cir_and_weight": 0 if od else None,
        "cross_request_layer0_uses_execution_npu_path": od,
        "runtime_cir_updates": False,
        "within_path_order": "FIFO, nonpreemptive I/O",
    }


if __name__ == "__main__":
    print(baseline_path_ids(8))
