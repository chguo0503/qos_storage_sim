"""Ring-only generation, immutable placement, and historical input preservation."""
from functools import lru_cache
import hashlib
import math
from pathlib import Path
import subprocess
import sys

import pytest

import sim
from continuous_batch_sim import continuous_batch_input_fingerprint
from run_baseline_npu32_stress import build_workload, load_manifest, save_manifest

ROOT = Path(__file__).resolve().parent


@lru_cache(maxsize=2)
def generated(blocks='exact'):
    return build_workload(family='raw', num_npu=2, num_ssu=3,
                          raw_keys='32:256,32:4096', horizon_ms=1,
                          seed=7, blocks=blocks)


def test_default_generator_uses_ring_and_conserves_profile_bytes():
    requests, metadata = generated()
    assert metadata['layout'] == sim.PLACEMENT_BLOCK_RING_HASH
    assert metadata['placement_identity_key'] == 'request_id'
    for request in requests:
        assert len(request.placement) == 1  # Same placement reused by all layers.
        layer = request.placement[0]
        assert [disk for disk, _ in layer] == [
            sim.block_ring_hash_disk_id(request.request_id, j, 3) for j in range(len(layer))]
        assert math.fsum(size for _, size in layer) == pytest.approx(
            request.load['per_layer_kv_gb'], abs=1e-12)
    explicit, explicit_meta = build_workload(family='raw', num_npu=2, num_ssu=3,
                                             raw_keys='32:256,32:4096', horizon_ms=1,
                                             seed=7, layout='hash')
    assert continuous_batch_input_fingerprint(requests) == continuous_batch_input_fingerprint(explicit)
    assert metadata == explicit_meta


@pytest.mark.parametrize('layout', ('local', 'stripe', 'hotspot'))
def test_retired_layouts_are_rejected_by_api_and_cli(layout):
    with pytest.raises(ValueError, match='Only ring-hash'):
        build_workload(layout=layout)
    result = subprocess.run([sys.executable, str(ROOT/'run_baseline_npu32_stress.py'),
                             '--layout', layout, '--describe-only'],
                            capture_output=True, text=True)
    assert result.returncode == 2
    assert 'invalid choice' in result.stderr


def test_manifest_roundtrip_retains_hash_placement_and_identity(tmp_path):
    requests, metadata = generated()
    path = tmp_path/'hash.json.gz'
    save_manifest(path, requests, metadata)
    restored, actual_meta = load_manifest(path)
    assert actual_meta == metadata
    assert continuous_batch_input_fingerprint(restored) == continuous_batch_input_fingerprint(requests)
    before = path.read_bytes()
    save_manifest(path, restored, actual_meta)
    assert path.read_bytes() == before


def test_archived_stripe_manifest_is_read_without_relabeling_or_rewriting():
    path = ROOT/'results/baseline_ab128_32_ratio12_20260912/slo_routing_ssu3_20260915/runs/baseline_seed7_remote_v2/manifest.json.gz'
    before = hashlib.sha256(path.read_bytes()).hexdigest()
    requests, metadata = load_manifest(path)
    assert len(requests) == 3840
    assert metadata['layout'] == 'stripe_npu_mod_ssu'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == before


def test_single_ssu_generator_is_ring_hash_degenerate_case():
    from run_baseline_4npu_ssu1_low_utilization import _placement
    profile = dict(seq_len_k=1, nql=128, per_layer_kv_gib=7*176*1024/2**30)
    layer = _placement(profile, request_id=23)
    assert len(layer) == 7
    assert {disk for disk, _ in layer} == {0}
    assert math.fsum(size for _, size in layer) == profile['per_layer_kv_gib']
